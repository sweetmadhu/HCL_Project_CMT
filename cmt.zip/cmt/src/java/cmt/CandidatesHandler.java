package cmt;

import java.sql.*;
import javax.servlet.jsp.tagext.*;
import javax.servlet.jsp.JspWriter;
import javax.servlet.jsp.JspException;

public class CandidatesHandler extends SimpleTagSupport {
     public void doTag() throws JspException {
       JspWriter out=getJspContext().getOut();
        try {
            // connect to database
            Connection con = Database.getConnection();
            PreparedStatement ps  = con.prepareStatement("select candid,name from candidates order by name");
            ResultSet  rs = ps.executeQuery();
            String output = "<select name=candid>";
            
            while ( rs.next())
               output += "<option value=" + rs.getString("candid") + ">" + rs.getString("name") + "</option>";
            output += "</select>";
            out.println(output);
          }
          catch( Exception ex)
          {
	     System.out.println( ex.getMessage() );
          }
     }
}

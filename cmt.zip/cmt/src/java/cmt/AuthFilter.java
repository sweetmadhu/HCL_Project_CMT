package cmt;

import java.io.*;
import java.net.*;
import java.util.*;
import java.text.*;
import javax.servlet.*;
import javax.servlet.http.*;

import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;

public class AuthFilter implements Filter {
    private FilterConfig filterConfig = null;
    public AuthFilter() {
    }
    
    public void doFilter(ServletRequest request, ServletResponse response,
            FilterChain chain)
            throws IOException, ServletException {
        
       HttpServletRequest req = (HttpServletRequest) request;
       HttpServletResponse res = (HttpServletResponse) response;
       //System.out.println(req.getRequestURL());
       // do it if it is not login.jsp 
       if ( req.getRequestURL().indexOf("index.jsp") == -1 )
       {
         Object logged = req.getSession().getAttribute("logged");
         if ( logged == null )
             res.sendRedirect("index.jsp");
       }
       chain.doFilter(request,response);
    }
    
    
    public FilterConfig getFilterConfig() {
        return (this.filterConfig);
    }
    public void setFilterConfig(FilterConfig filterConfig) {
       this.filterConfig = filterConfig;
    }
    
    public void destroy() {}
    public void init(FilterConfig c) {}
}

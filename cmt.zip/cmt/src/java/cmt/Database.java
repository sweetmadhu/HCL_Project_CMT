package cmt;
import java.sql.*;
public class Database {
  public final static String uname = "cmt";
  public final static String password = "cmt";
  public final static String driver="oracle.jdbc.driver.OracleDriver";
  public final static String url="jdbc:oracle:thin:@localhost:1521:xe";
    
  public static Connection getConnection()
  {
   try
   {            
    Class.forName( driver);
    Connection con = DriverManager.getConnection(url,uname,password);
    return con;
   }
   catch(Exception ex)
   {
       System.out.println(ex.getMessage());
       return null;
   }
  }
  
  public static void clean(Connection con, Statement st)
  {
      try
      {
          st.close();
          con.close();
      }
      catch(Exception ex) {}
  }

     
}

package cmt;

import java.sql.*;
import javax.servlet.jsp.tagext.*;
import javax.servlet.jsp.JspWriter;
import javax.servlet.jsp.JspException;

public class ClientsHandler extends SimpleTagSupport {
     public void doTag() throws JspException {
       JspWriter out=getJspContext().getOut();
        try {
            // connect to database
            Connection con = Database.getConnection();
            PreparedStatement ps  = con.prepareStatement("select clientid,name from clients order by name");
            ResultSet  rs = ps.executeQuery();
            String output = "<select name=clientid>";
            
            while ( rs.next())
               output += "<option value=" + rs.getString("clientid") + ">" + rs.getString("name") + "</option>";
            output += "</select>";
            out.println(output);
          }
          catch( Exception ex)
          {
	     System.out.println( ex.getMessage() );
          }
     }
}

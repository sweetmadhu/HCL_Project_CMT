create table users
(  uname  varchar(10) primary key,
   pwd    varchar(10),
   fullname varchar(30)
);

insert into users values('a','a','Andy Hill');
insert into users values('s','s','Stephen Walther');
commit;

create table clients
(clientid  number(5) primary key,
 name      varchar(30),
 location  varchar(30),
 email     varchar(50) unique
);


create table candidates
(candid  number(5) primary key,
 name      varchar(30),
 qual      varchar(50),
 skills    varchar(200),
 exp       number(2),
 email     varchar(50) unique
);

create table contracts
(contractid  number(5) primary key,
 clientid    number(5) references clients(clientid),
 candid      number(5) references candidates(candid),
 location  varchar(30),
 stdate    date,
 duration  number(3)
);

create table requirements
(reqid number(5) primary key,
 clientid    number(5) references clients(clientid),
 jobtitle    varchar(30),
 jobdesc     varchar(200),
 location    varchar(30)
);

insert into clients values(1,'L&T','Delhi,India','info@landt.com');
insert into clients values(2,'ICICI','Bangalore,India','contact@icicibank.com');


insert into requirements
 values(1,1,'Oracle DBA','Oracle DBA','Chennai,India');
insert into requirements
 values(2,1,'PL/SQL Developer','Candidate with sound knowledge of PL/SQL and Pro*C','Bangalore,India');


insert into candidates
 values(100,'Stephen','MS CS','.NET and SQL Server',4,'stephen@hotmail.com');

insert into candidates
 values(101,'Jason','BE CS','Java, JSP, EJB',3,'jason@yahoo.com');

insert into candidates
 values(102,'Dennis','MCA','C, C++, COM',5,'dennis@gmail.com');

insert into contracts
values(1001,1,102,'Vizag,India','10-sep-06',24);

insert into contracts
values(1002,1,100,'Bangalore,India','1-aug-06',12);